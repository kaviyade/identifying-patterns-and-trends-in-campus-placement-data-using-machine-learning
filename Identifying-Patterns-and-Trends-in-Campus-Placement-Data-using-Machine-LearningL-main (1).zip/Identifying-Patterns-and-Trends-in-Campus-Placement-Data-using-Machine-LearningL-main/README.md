# Identifying-Patterns-and-Trends-in-Campus-Placement-Data-using-Machine-LearningL
link: https://drive.google.com/file/d/1Bsk9PFBOMLL2Coi6cABxJ4nuSfVj0vI2/view?usp=drivesdk
